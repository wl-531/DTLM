import numpy as np


def _filtered_requests(results, skip_warmup=True):
    return [row for row in results if not (skip_warmup and row[4])]


def _filtered_cold_events(results, skip_warmup=True):
    events = getattr(results, "cold_start_events", None)
    if events is None:
        filtered = _filtered_requests(results, skip_warmup=skip_warmup)
        return [
            {"timestamp_ms": ts, "func_id": fid, "reason": "initial", "is_warmup": is_warmup}
            for ts, fid, is_cold, mem_used, is_warmup in filtered
            if is_cold
        ]
    return [event for event in events if not (skip_warmup and event["is_warmup"])]


def _filtered_minute_utils(results, M, skip_warmup=True):
    samples = getattr(results, "minute_samples", None) or []
    values = [
        sample["memory_utilization"]
        for sample in samples
        if not (skip_warmup and sample["is_warmup"])
    ]
    if values:
        return values
    if M <= 0:
        return []
    return [mem_used / M for _, _, _, mem_used, _ in _filtered_requests(results, skip_warmup=skip_warmup)]


def _filtered_removal_utils(results, reason, skip_warmup=True):
    events = getattr(results, "removal_events", None) or []
    warmup_end_ms = getattr(results, "warmup_end_ms", None)
    return [
        event["memory_utilization"]
        for event in events
        if event["reason"] == reason
        and not (
            skip_warmup
            and warmup_end_ms is not None
            and event["timestamp_ms"] < warmup_end_ms
        )
    ]


def _quantile(values, q, default=0.0):
    if not values:
        return default
    return float(np.quantile(values, q))


def _distribution(values, empty_value=None):
    if not values:
        return {
            "count": 0,
            "mean": empty_value,
            "p50": empty_value,
            "p95": empty_value,
        }
    return {
        "count": len(values),
        "mean": float(np.mean(values)),
        "p50": _quantile(values, 0.50),
        "p95": _quantile(values, 0.95),
    }


def cold_start_rate(results, skip_warmup=True):
    filtered = _filtered_requests(results, skip_warmup=skip_warmup)
    if not filtered:
        return 0.0
    cold_count = sum(1 for _, _, is_cold, _, _ in filtered if is_cold)
    return cold_count / len(filtered)


def total_cold_start_cost(results, functions_info, skip_warmup=True):
    cost = 0.0
    for event in _filtered_cold_events(results, skip_warmup=skip_warmup):
        cost += functions_info.get(event["func_id"], {}).get("c_i", 0)
    return cost


def avg_memory_utilization(results, M, skip_warmup=True):
    values = _filtered_minute_utils(results, M, skip_warmup=skip_warmup)
    if not values:
        return 0.0
    return float(np.mean(values))


def peak_memory(results, skip_warmup=True):
    filtered = [mem_used for _, _, _, mem_used, _ in _filtered_requests(results, skip_warmup=skip_warmup)]
    if not filtered:
        return 0.0
    return max(filtered)


def cold_start_breakdown(results, functions_info, skip_warmup=True):
    breakdown = {
        "expiry_induced": {"count": 0, "cost": 0.0},
        "eviction_induced": {"count": 0, "cost": 0.0},
        "initial": {"count": 0, "cost": 0.0},
    }
    for event in _filtered_cold_events(results, skip_warmup=skip_warmup):
        reason = event["reason"]
        if reason not in breakdown:
            continue
        breakdown[reason]["count"] += 1
        breakdown[reason]["cost"] += functions_info.get(event["func_id"], {}).get("c_i", 0)
    return breakdown


def per_function_costs(results, functions_info, skip_warmup=True):
    events = getattr(results, "cold_start_events", None)
    if events is None:
        costs = {}
        for ts, func_id, is_cold, mem_used, is_warmup in _filtered_requests(results, skip_warmup=skip_warmup):
            if is_cold:
                costs[func_id] = costs.get(func_id, 0.0) + functions_info.get(func_id, {}).get("c_i", 0.0)
        return costs

    costs = {}
    for event in _filtered_cold_events(results, skip_warmup=skip_warmup):
        func_id = event["func_id"]
        cost = event.get("cost", functions_info.get(func_id, {}).get("c_i", 0.0))
        costs[func_id] = costs.get(func_id, 0.0) + cost
    return costs


def per_function_request_counts(results, skip_warmup=True):
    counts = {}
    for _, func_id, _, _, is_warmup in results:
        if skip_warmup and is_warmup:
            continue
        counts[func_id] = counts.get(func_id, 0) + 1
    return counts


def summary(results, functions_info, M, memory_unconstrained=False, skip_warmup=True):
    filtered = _filtered_requests(results, skip_warmup=skip_warmup)
    total_reqs = len(filtered)
    total_colds = sum(1 for _, _, is_cold, _, _ in filtered if is_cold)
    cold_breakdown = cold_start_breakdown(results, functions_info, skip_warmup=skip_warmup)
    util_values = _filtered_minute_utils(results, M, skip_warmup=skip_warmup)
    ttl_delete_stats = _distribution(
        _filtered_removal_utils(results, "expiry", skip_warmup=skip_warmup),
        empty_value=None,
    )
    eviction_delete_stats = _distribution(
        _filtered_removal_utils(results, "eviction", skip_warmup=skip_warmup),
        empty_value=None,
    )

    return {
        "cold_start_rate": cold_start_rate(results, skip_warmup),
        "total_cold_start_cost": total_cold_start_cost(results, functions_info, skip_warmup),
        "avg_memory_utilization": avg_memory_utilization(results, M, skip_warmup),
        "memory_utilization_p5": _quantile(util_values, 0.05),
        "memory_utilization_p50": _quantile(util_values, 0.50),
        "memory_utilization_p95": _quantile(util_values, 0.95),
        "peak_memory_mb": peak_memory(results, skip_warmup),
        "total_requests": total_reqs,
        "total_cold_starts": total_colds,
        "memory_unconstrained": memory_unconstrained,
        "expiry_induced_cold_starts": cold_breakdown["expiry_induced"]["count"],
        "expiry_induced_cold_start_cost": cold_breakdown["expiry_induced"]["cost"],
        "eviction_induced_cold_starts": cold_breakdown["eviction_induced"]["count"],
        "eviction_induced_cold_start_cost": cold_breakdown["eviction_induced"]["cost"],
        "initial_cold_starts": cold_breakdown["initial"]["count"],
        "initial_cold_start_cost": cold_breakdown["initial"]["cost"],
        "ttl_delete_count": ttl_delete_stats["count"],
        "ttl_delete_utilization_mean": ttl_delete_stats["mean"],
        "ttl_delete_utilization_p50": ttl_delete_stats["p50"],
        "ttl_delete_utilization_p95": ttl_delete_stats["p95"],
        "eviction_delete_count": eviction_delete_stats["count"],
        "eviction_delete_utilization_mean": eviction_delete_stats["mean"],
        "eviction_delete_utilization_p50": eviction_delete_stats["p50"],
        "eviction_delete_utilization_p95": eviction_delete_stats["p95"],
        "per_function_request_counts": per_function_request_counts(results, skip_warmup),
        "per_function_costs": per_function_costs(results, functions_info, skip_warmup),
    }
