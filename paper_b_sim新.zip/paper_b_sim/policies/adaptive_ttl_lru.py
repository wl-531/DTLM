from policies.base import CachePolicy

EMA_ALPHA = 0.3
DEFAULT_MULTIPLIER = 2.0


class AdaptiveTTL_LRU(CachePolicy):
    """Adaptive TTL plus LRU eviction."""

    def __init__(self, M, functions_info, multiplier=DEFAULT_MULTIPLIER):
        super().__init__(M, functions_info)
        self.multiplier = multiplier
        self.warm = {}  # func_id -> {m_i, last_access}
        self.ema_iat = {}
        self.last_arrival = {}
        self._mem_used = 0.0

    def _expire(self, func_id, current_time_ms):
        self.record_removal(func_id, "expiry", current_time_ms)
        self._mem_used -= self.warm[func_id]["m_i"]
        del self.warm[func_id]

    def _evict_one(self, timestamp_ms):
        victim = min(self.warm, key=lambda f: self.warm[f]["last_access"])
        self.record_removal(victim, "eviction", timestamp_ms)
        self._mem_used -= self.warm[victim]["m_i"]
        del self.warm[victim]

    def _get_ttl(self, func_id):
        if func_id in self.ema_iat:
            return self.ema_iat[func_id] * self.multiplier
        return 600000

    def _update_iat(self, func_id, timestamp_ms):
        if func_id in self.last_arrival:
            iat = timestamp_ms - self.last_arrival[func_id]
            if func_id in self.ema_iat:
                self.ema_iat[func_id] = EMA_ALPHA * iat + (1 - EMA_ALPHA) * self.ema_iat[func_id]
            else:
                self.ema_iat[func_id] = iat
        self.last_arrival[func_id] = timestamp_ms

    def check_ttl(self, current_time_ms):
        expired = []
        for fid, entry in self.warm.items():
            ttl = self._get_ttl(fid)
            if current_time_ms - entry["last_access"] > ttl:
                expired.append(fid)
        for fid in expired:
            self._expire(fid, current_time_ms)

    def on_request(self, timestamp_ms, func_id):
        self._update_iat(func_id, timestamp_ms)
        if func_id in self.warm:
            self.warm[func_id]["last_access"] = timestamp_ms
            return False
        m_i = self.functions_info[func_id]["m_i"]
        while self._mem_used + m_i > self.M and self.warm:
            self._evict_one(timestamp_ms)
        self.warm[func_id] = {"m_i": m_i, "last_access": timestamp_ms}
        self._mem_used += m_i
        return True

    def memory_used(self):
        return self._mem_used

    def get_state(self):
        return dict(self.warm)
