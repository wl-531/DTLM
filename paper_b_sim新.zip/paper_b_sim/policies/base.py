class CachePolicy:
    def __init__(self, M, functions_info):
        """Base cache policy."""
        self.M = M
        self.functions_info = functions_info
        self.last_removal_reason = {}
        self.removal_events = []

    def on_request(self, timestamp_ms, func_id):
        """Handle one request and return True on cold start."""
        raise NotImplementedError

    def check_ttl(self, current_time_ms):
        """Run TTL scan. Policies without TTL can keep the default no-op."""
        pass

    def get_state(self):
        """Return the current cache state snapshot."""
        raise NotImplementedError

    def memory_used(self):
        """Return current memory usage in MB."""
        raise NotImplementedError

    def current_memory_utilization(self):
        if self.M <= 0:
            return 0.0
        return self.memory_used() / self.M

    def record_removal(self, func_id, reason, timestamp_ms):
        if reason not in {"expiry", "eviction"}:
            return
        self.last_removal_reason[func_id] = reason
        self.removal_events.append({
            "timestamp_ms": timestamp_ms,
            "func_id": func_id,
            "reason": reason,
            "memory_utilization": self.current_memory_utilization(),
        })

    def cold_start_reason(self, func_id):
        reason = self.last_removal_reason.get(func_id)
        if reason == "expiry":
            return "expiry_induced"
        if reason == "eviction":
            return "eviction_induced"
        return "initial"
