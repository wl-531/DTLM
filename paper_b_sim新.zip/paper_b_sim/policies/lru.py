from policies.base import CachePolicy


class LRU(CachePolicy):
    def __init__(self, M, functions_info):
        super().__init__(M, functions_info)
        self.warm = {}  # func_id -> {m_i, last_access}
        self._mem_used = 0.0

    def _evict_one(self, timestamp_ms):
        victim = min(self.warm, key=lambda f: self.warm[f]["last_access"])
        self.record_removal(victim, "eviction", timestamp_ms)
        self._mem_used -= self.warm[victim]["m_i"]
        del self.warm[victim]

    def on_request(self, timestamp_ms, func_id):
        if func_id in self.warm:
            self.warm[func_id]["last_access"] = timestamp_ms
            return False
        m_i = self.functions_info[func_id]["m_i"]
        while self._mem_used + m_i > self.M and self.warm:
            self._evict_one(timestamp_ms)
        self.warm[func_id] = {"m_i": m_i, "last_access": timestamp_ms}
        self._mem_used += m_i
        return True

    def memory_used(self):
        return self._mem_used

    def get_state(self):
        return dict(self.warm)
