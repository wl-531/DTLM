from policies.base import CachePolicy

FIXED_TTL_MS = 600000  # 10 minutes


class FixedTTL_LRU(CachePolicy):
    def __init__(self, M, functions_info):
        super().__init__(M, functions_info)
        self.warm = {}  # func_id -> {m_i, last_access}
        self._mem_used = 0.0
        self.ttl_expire_count = 0

    def _expire(self, func_id, current_time_ms):
        self.record_removal(func_id, "expiry", current_time_ms)
        self._mem_used -= self.warm[func_id]["m_i"]
        del self.warm[func_id]
        self.ttl_expire_count += 1

    def _evict_one(self, timestamp_ms):
        victim = min(self.warm, key=lambda f: self.warm[f]["last_access"])
        self.record_removal(victim, "eviction", timestamp_ms)
        self._mem_used -= self.warm[victim]["m_i"]
        del self.warm[victim]

    def check_ttl(self, current_time_ms):
        expired = [
            fid
            for fid, entry in self.warm.items()
            if current_time_ms - entry["last_access"] >= FIXED_TTL_MS
        ]
        for fid in expired:
            self._expire(fid, current_time_ms)

    def on_request(self, timestamp_ms, func_id):
        if func_id in self.warm:
            self.warm[func_id]["last_access"] = timestamp_ms
            return False
        m_i = self.functions_info[func_id]["m_i"]
        while self._mem_used + m_i > self.M and self.warm:
            self._evict_one(timestamp_ms)
        self.warm[func_id] = {"m_i": m_i, "last_access": timestamp_ms}
        self._mem_used += m_i
        return True

    def memory_used(self):
        return self._mem_used

    def get_state(self):
        return dict(self.warm)
