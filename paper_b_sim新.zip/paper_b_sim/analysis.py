def _extract_metrics_payload(result):
    if isinstance(result, dict):
        return result.get("metrics", result)
    return None


def _extract_per_function_costs(result):
    metrics = _extract_metrics_payload(result)
    if metrics is not None and "per_function_costs" in metrics:
        return dict(metrics["per_function_costs"])
    return dict(getattr(result, "per_function_cost", {}))


def _extract_request_counts(result):
    metrics = _extract_metrics_payload(result)
    if metrics is not None and "per_function_request_counts" in metrics:
        return dict(metrics["per_function_request_counts"])
    if isinstance(result, dict) and "per_function_request_counts" in result:
        return dict(result["per_function_request_counts"])
    return dict(getattr(result, "per_function_requests", {}))


def _extract_functions_info(result):
    if isinstance(result, dict):
        if "functions_info" in result:
            return dict(result["functions_info"])
        if "function_features" in result:
            return {
                func_id: {"m_i": features.get("memory"), "c_i": features.get("cold_cost")}
                for func_id, features in result["function_features"].items()
            }
        return {}
    return dict(getattr(result, "functions_info", {}))


def _classify_hotness(request_counts):
    non_zero = sorted(count for count in request_counts.values() if count > 0)
    if not non_zero:
        return {}, 0, 0

    p50_idx = int(0.50 * (len(non_zero) - 1))
    p80_idx = int(0.80 * (len(non_zero) - 1) + 0.999999)
    warm_threshold = non_zero[p50_idx]
    hot_threshold = non_zero[p80_idx]

    categories = {}
    for func_id, count in request_counts.items():
        if count >= hot_threshold:
            categories[func_id] = "hot"
        elif count >= warm_threshold:
            categories[func_id] = "warm"
        else:
            categories[func_id] = "cold"
    return categories, warm_threshold, hot_threshold


def _build_ranked_rows(delta_costs, request_counts, functions_info, categories, top_n, reverse):
    ordered = sorted(delta_costs.items(), key=lambda item: item[1], reverse=reverse)
    rows = []
    for func_id, delta_cost in ordered:
        if reverse and delta_cost <= 0:
            continue
        if not reverse and delta_cost >= 0:
            continue
        info = functions_info.get(func_id, {})
        rows.append({
            "func_id": func_id,
            "delta_cost": float(delta_cost),
            "dtlm_cost": 0.0,
            "gdsf_cost": 0.0,
            "freq": int(request_counts.get(func_id, 0)),
            "memory": info.get("m_i"),
            "cold_cost": info.get("c_i"),
            "category": categories.get(func_id, "unknown"),
        })
        if len(rows) >= top_n:
            break
    return rows


def function_attribution(dtlm_results, gdsf_results):
    """Compare DTLM vs GDSF per-function cold-start cost."""
    dtlm_costs = _extract_per_function_costs(dtlm_results)
    gdsf_costs = _extract_per_function_costs(gdsf_results)
    request_counts = _extract_request_counts(dtlm_results) or _extract_request_counts(gdsf_results)
    functions_info = _extract_functions_info(dtlm_results) or _extract_functions_info(gdsf_results)

    all_funcs = set(dtlm_costs) | set(gdsf_costs) | set(request_counts) | set(functions_info)
    categories, warm_threshold, hot_threshold = _classify_hotness(
        {func_id: request_counts.get(func_id, 0) for func_id in all_funcs}
    )

    delta_costs = {
        func_id: float(dtlm_costs.get(func_id, 0.0) - gdsf_costs.get(func_id, 0.0))
        for func_id in all_funcs
    }

    top_harmful = _build_ranked_rows(delta_costs, request_counts, functions_info, categories, top_n=10, reverse=True)
    top_beneficial = _build_ranked_rows(delta_costs, request_counts, functions_info, categories, top_n=10, reverse=False)

    for row in top_harmful + top_beneficial:
        func_id = row["func_id"]
        row["dtlm_cost"] = float(dtlm_costs.get(func_id, 0.0))
        row["gdsf_cost"] = float(gdsf_costs.get(func_id, 0.0))

    net_effect_by_category = {}
    for category in ["hot", "warm", "cold"]:
        members = [func_id for func_id, func_category in categories.items() if func_category == category]
        net_effect_by_category[category] = {
            "function_count": len(members),
            "dtlm_cost": float(sum(dtlm_costs.get(func_id, 0.0) for func_id in members)),
            "gdsf_cost": float(sum(gdsf_costs.get(func_id, 0.0) for func_id in members)),
            "delta_cost": float(sum(delta_costs.get(func_id, 0.0) for func_id in members)),
        }

    return {
        "top_10_harmful": top_harmful,
        "top_10_beneficial": top_beneficial,
        "net_effect_by_category": net_effect_by_category,
        "category_thresholds": {
            "warm_request_count_p50": int(warm_threshold),
            "hot_request_count_p80": int(hot_threshold),
        },
    }
