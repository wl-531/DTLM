class SimulationResults(list):
    """List-compatible simulation output with extra metric streams."""

    def __init__(self, warmup_end_ms=None, functions_info=None):
        super().__init__()
        self.warmup_end_ms = warmup_end_ms
        self.functions_info = functions_info or {}
        self.minute_samples = []
        self.cold_start_events = []
        self.removal_events = []
        self.per_function_cost = {}
        self.per_function_requests = {}


def simulate(policy, request_stream, warmup_end_ms=None):
    """Run event-driven simulation."""
    results = SimulationResults(warmup_end_ms=warmup_end_ms, functions_info=policy.functions_info)
    total = len(request_stream)
    next_ttl_check_time = 60000

    for i, (ts, func_id, app_id, m_mb) in enumerate(request_stream):
        while ts >= next_ttl_check_time:
            policy.check_ttl(next_ttl_check_time)
            results.minute_samples.append({
                "timestamp_ms": next_ttl_check_time,
                "memory_utilization": policy.current_memory_utilization(),
                "is_warmup": warmup_end_ms is not None and next_ttl_check_time < warmup_end_ms,
            })
            next_ttl_check_time += 60000

        is_cold = policy.on_request(ts, func_id)
        mem_used = policy.memory_used()
        is_warmup = warmup_end_ms is not None and ts < warmup_end_ms
        results.append((ts, func_id, is_cold, mem_used, is_warmup))
        results.per_function_requests[func_id] = results.per_function_requests.get(func_id, 0) + 1

        if is_cold:
            cold_cost = policy.functions_info.get(func_id, {}).get("c_i", 0.0)
            results.per_function_cost[func_id] = results.per_function_cost.get(func_id, 0.0) + cold_cost
            results.cold_start_events.append({
                "timestamp_ms": ts,
                "func_id": func_id,
                "reason": policy.cold_start_reason(func_id),
                "cost": cold_cost,
                "is_warmup": is_warmup,
            })

        if (i + 1) % 100000 == 0:
            print(f"Progress: {i+1} / {total}")

    results.removal_events = list(policy.removal_events)
    print(f"Simulation done: {total} requests processed")
    return results
